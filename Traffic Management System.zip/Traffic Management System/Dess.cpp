#include <iostream>
#include <windows.h> // For Sleep function

using namespace std;

class TrafficLight {
private:
    bool isGreen;

public:
    TrafficLight() : isGreen(false) {}

    void turnGreen() {
        isGreen = true;
        cout << "Traffic light turned green." << endl;
    }

    void turnRed() {
        isGreen = false;
        cout << "Traffic light turned red." << endl;
        cout << "ALL VEHICLES MUST TOP MOVING" << endl;
    }

    bool isGreenSignal() const {
        return isGreen;
    }
};

class Vehicle {
public:
    virtual void move() = 0;
};

class Car : public Vehicle {
public:
    void move() override {
        cout << "Car is moving." << endl;
    }
};

class Bus : public Vehicle {
public:
    void move() override {
        cout << "Bus is moving." << endl;
    }
};

int main() {
    Car car;
    Bus bus;

    TrafficLight trafficLight;

    trafficLight.turnGreen();
    for (int i = 0; i < 5; ++i) {
        if (trafficLight.isGreenSignal()) {
            car.move();
            bus.move();
        } else {
            cout << "Traffic light is red." << endl;
        }

        Sleep(2000); // Delay to simulate time passing
    }
    trafficLight.turnRed();

    return 0;
}